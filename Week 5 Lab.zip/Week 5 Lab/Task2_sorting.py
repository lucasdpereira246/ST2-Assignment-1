import random
import timeit
from recursion_mergesort import merge_sort, insertion_sort

sizes = [50, 200, 500, 1000]

print("Benchmarking Merge Sort vs Insertion Sort...\n")

for size in sizes:
    data = [random.randint(1, 10000) for _ in range(size)]

    insertion_time = timeit.timeit(lambda: insertion_sort(data[:]), number=5)
    merge_time= timeit.timeit(lambda: merge_sort(data[:]), number=5)

    print(f"DATA SIZE = {size}")
    print(f"Insertion Sort: {insertion_time:.6f} seconds")
    print(f"Merge Sort:     {merge_time:.6f} seconds")
    print("-" * 40)