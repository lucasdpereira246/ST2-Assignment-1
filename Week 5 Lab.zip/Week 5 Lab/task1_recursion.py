import timeit

# -----------------------------
# RECURSIVE VERSIONS
# -----------------------------

def sum_recursive(n):
    if n == 1:
        return 1
    return n + sum_recursive(n - 1)

def fibonacci_recursive(n):
    if n <= 0:
        return 0
    if n == 1:
        return 1
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2)

def factorial_recursive(n):
    if n == 0:
        return 1
    return n * factorial_recursive(n - 1)

# -----------------------------
# ITERATIVE VERSIONS
# -----------------------------

def sum_iter(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total

def fibonacci_iter(n):
    if n <= 0:
        return 0
    a, b = 0, 1
    if n == 1:
        return 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

def factorial_iter(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# -----------------------------
# BENCHMARKING
# -----------------------------

print("Benchmarking recursion vs iteration...\n")

print("Sum Recursive:", timeit.timeit(lambda: sum_recursive(500), number=100))
print("Sum Iterative:", timeit.timeit(lambda: sum_iter(500), number=100))

print("\nFactorial Recursive:", timeit.timeit(lambda: factorial_recursive(10), number=1000))
print("Factorial Iterative:", timeit.timeit(lambda: factorial_iter(10), number=1000))

print("\nFibonacci Recursive:", timeit.timeit(lambda: fibonacci_recursive(20), number=10))
print("Fibonacci Iterative:", timeit.timeit(lambda: fibonacci_iter(20), number=10))