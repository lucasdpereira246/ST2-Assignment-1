from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 400
        self.height = 400

        self.canvas = Canvas(window,width=self.width, height=self.height)
        self.canvas.pack()

        frame = Frame(window)
        frame.pack()

        Label(frame, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame, textvariable=self.order, width=5).pack(side=LEFT)
        Button(frame, text="Display", command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")

        p1 = (200, 20)
        p2 = (20, 350)
        p3 = (380, 350)

        order = int(self.order.get())

        self.draw_koch(order, p1, p2)
        self.draw_koch(order, p2, p3)
        self.draw_koch(order, p3, p1)

    def draw_koch(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            x1, y1 = p1
            x2, y2 = p2

            dx = (x2 - x1) / 3
            dy = (y2 - y1) / 3

            pA = (x1+ dx, y1 + dy)
            pB = (x1+ 2 * dx, y1 + 2 * dy)

            angle = math.radians(60)
            px = pA[0] + (dx * math.cos(angle) - dy * math.sin(angle))
            py = pA[1] + (dx *math.sin(angle) + dy * math.cos(angle))
            pC = (px, py)

            self.draw_koch(order - 1, p1, pA)
            self.draw_koch(order - 1, pA, pC)
            self.draw_koch(order - 1, pC, pB)
            self.draw_koch(order- 1, pB, p2)

if __name__ == "__main__":
    KochSnowflake()