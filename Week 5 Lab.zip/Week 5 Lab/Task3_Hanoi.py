moves = 0  # global counter

def moveDisks(n, fromTower, toTower, auxTower):
    global moves
    if n == 1:
        moves += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        moves += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)

def main():
    global moves
    n = int(input("Enter number of disks: "))
    moves = 0
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print("Number of moves is", moves)

if __name__ == "__main__":
    main()