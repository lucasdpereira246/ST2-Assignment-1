import random
import string
import time

# ---- BST Node ----
class BSTNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

def bst_insert(root, key):
    if root is None:
        return BSTNode(key)
    if key < root.key:
        root.left = bst_insert(root.left, key)
    else:
        root.right = bst_insert(root.right, key)
    return root

def bst_search(root, key):
    if root is None or root.key == key:
        return root
    if key < root.key:
        return bst_search(root.left, key)
    return bst_search(root.right, key)

# ---- AVL Tree ----
class AVLNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1

def height(node):
    return node.height if node else 0

def balance(node):
    return height(node.left) - height(node.right) if node else 0

def rotate_left(x):
    y = x.right
    T2 = y.left
    y.left = x
    x.right = T2
    x.height = 1 + max(height(x.left), height(x.right))
    y.height = 1 + max(height(y.left), height(y.right))
    return y

def rotate_right(y):
    x = y.left
    T2 = x.right
    x.right = y
    y.left = T2
    y.height = 1 + max(height(y.left), height(y.right))
    x.height = 1 + max(height(x.left), height(x.right))
    return x

def avl_insert(node, key):
    if not node:
        return AVLNode(key)
    if key < node.key:
        node.left = avl_insert(node.left, key)
    else:
        node.right = avl_insert(node.right, key)

    node.height = 1 + max(height(node.left), height(node.right))
    b = balance(node)

    # LL
    if b > 1 and key < node.left.key:
        return rotate_right(node)
    # RR
    if b < -1 and key > node.right.key:
        return rotate_left(node)
    # LR
    if b > 1 and key > node.left.key:
        node.left = rotate_left(node.left)
        return rotate_right(node)
    # RL
    if b < -1 and key < node.right.key:
        node.right = rotate_right(node.right)
        return rotate_left(node)

    return node

def avl_search(node, key):
    if node is None or node.key == key:
        return node
    if key < node.key:
        return avl_search(node.left, key)
    return avl_search(node.right, key)

# ---- Benchmark ----
def random_string():
    return ''.join(random.choices(string.ascii_lowercase, k=7))

if __name__ == "__main__":
    N = 10000
    keys = [random_string() for _ in range(N)]

    # BST Benchmark
    bst_root = None
    start = time.time()
    for k in keys:
        bst_root = bst_insert(bst_root, k)
    bst_insert_time = time.time() - start

    start = time.time()
    for k in keys:
        bst_search(bst_root, k)
    bst_search_time = time.time() - start

    # AVL Benchmark
    avl_root = None
    start = time.time()
    for k in keys:
        avl_root = avl_insert(avl_root, k)
    avl_insert_time = time.time() - start

    start = time.time()
    for k in keys:
        avl_search(avl_root, k)
    avl_search_time = time.time() - start

    print("---- Benchmark Results ----")
    print(f"BST Insert Time: {bst_insert_time:.4f}s")
    print(f"BST Search Time: {bst_search_time:.4f}s")
    print(f"AVL Insert Time: {avl_insert_time:.4f}s")
    print(f"AVL Search Time: {avl_search_time:.4f}s")