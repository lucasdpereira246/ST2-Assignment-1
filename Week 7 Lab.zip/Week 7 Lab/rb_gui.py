import tkinter as tk
from tkinter import messagebox
from rb_tree import RBTree, RED, BLACK

class RBApp:
    def __init__(self, master):
        self.tree = RBTree()
        self.master = master
        master.title("Red-Black Tree Contact Directory")

        frame = tk.Frame(master)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1)

        btn_frame = tk.Frame(master)
        btn_frame.pack(pady=5)

        tk.Button(btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Show All", command=self.show_all).grid(row=0, column=2, padx=5)

        self.output_text = tk.Text(master, height=10, width=60)
        self.output_text.pack(pady=10)

        self.canvas = tk.Canvas(master, width=800, height=400, bg="white")
        self.canvas.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return
        self.tree.insert(name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to search.")
            return
        node = self.tree.search(name)
        self.output_text.delete(1.0, tk.END)
        if node:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.key}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        def inorder(node):
            if node is None or node.key is None:
                return
            inorder(node.left)
            color = "RED" if node.color == RED else "BLACK"
            self.output_text.insert(tk.END, f"{node.key} - {node.phone} ({color})\n")
            inorder(node.right)

        inorder(self.tree.root)

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root.key is None:
            return
        width = self.canvas.winfo_width()
        self._draw_node(self.tree.root, width // 2, 20, width // 4)

    def _draw_node(self, node, x, y, x_offset):
        if node is None or node.key is None:
            return

        radius = 20

        if node.left and node.left.key is not None:
            x_left = x - x_offset
            y_left = y + 70
            self.canvas.create_line(x, y + radius, x_left, y_left - radius)
            self._draw_node(node.left, x_left, y_left, x_offset // 2)

        if node.right and node.right.key is not None:
            x_right = x + x_offset
            y_right = y + 70
            self.canvas.create_line(x, y + radius, x_right, y_right - radius)
            self._draw_node(node.right, x_right, y_right, x_offset // 2)

        fill_color = "red" if node.color == RED else "black"
        text_color = "white"
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=fill_color)
        display_key = node.key if len(node.key) <= 10 else node.key[:10] + "..."
        self.canvas.create_text(x, y, text=display_key, fill=text_color, font=("Arial", 10, "bold"))

if __name__ == "__main__":
    root = tk.Tk()
    app = RBApp(root)
    root.mainloop()