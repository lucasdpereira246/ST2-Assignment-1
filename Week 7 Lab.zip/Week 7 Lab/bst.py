class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

# Preorder Traversal (Root-Left-Right)
def preorder(root):
    if root:
        print(root.value, end=' ')
        preorder(root.left)
        preorder(root.right)

# Inorder Traversal (Left-Root-Right)
def inorder(root):
    if root:
        inorder(root.left)
        print(root.value, end=' ')
        inorder(root.right)

# Postorder Traversal (Left-Right-Root)
def postorder(root):
    if root:
        postorder(root.left)
        postorder(root.right)
        print(root.value, end=' ')

# Count total nodes
def count_nodes(root):
    if root is None:
        return 0
    return 1 + count_nodes(root.left) + count_nodes(root.right)

# Height of tree
def height(root):
    if root is None:
        return 0
    return 1 + max(height(root.left), height(root.right))

# Search in BST
def search_bst(root, val):
    if root is None or root.value == val:
        return root
    if val < root.value:
        return search_bst(root.left, val)
    return search_bst(root.right, val)

# Insert into BST
def insert_bst(root, val):
    if root is None:
        return Node(val)
    if val < root.value:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root

# Find minimum value node
def find_min(root):
    current = root
    while current.left:
        current = current.left
    return current

# Delete node
def delete_node(root, val):
    if root is None:
        return root
    if val < root.value:
        root.left = delete_node(root.left, val)
    elif val > root.value:
        root.right = delete_node(root.right, val)
    else:
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left
        temp = find_min(root.right)
        root.value = temp.value
        root.right = delete_node(root.right, temp.value)
    return root

# ---- TESTING ----
if __name__ == "__main__":
    root = None
    for v in [50, 30, 70, 20, 40, 60, 80]:
        root = insert_bst(root, v)

    print("Preorder:")
    preorder(root)
    print("\nInorder:")
    inorder(root)
    print("\nPostorder:")
    postorder(root)

    print("\nTotal nodes:", count_nodes(root))
    print("Height:", height(root))

    print("\nSearching for 40:", search_bst(root, 40) is not None)
    print("Deleting 30...")
    root = delete_node(root, 30)
    print("Inorder after deletion:")
    inorder(root)